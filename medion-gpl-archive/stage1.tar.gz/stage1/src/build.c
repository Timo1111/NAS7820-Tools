/*******************************************************************
 *
 * Description:     build date and time insertion file. 
 *
 * Author:          J J Larkworthy
 *
 * Copyright:       Oxford Semiconductor Ltd, 2009
 *
 *******************************************************************/
#include "types.h"
char * build_string=BUILD_DATE;

